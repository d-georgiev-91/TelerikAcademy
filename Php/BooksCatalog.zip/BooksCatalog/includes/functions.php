<?php

mb_internal_encoding('UTF-8');

function connectToDatabase() {
    $connection = mysqli_connect('localhost', 'admin', 'admin', 'books');

    if (!$connection) {
        throw new Exception('No connection with database!');
    }

    mysqli_set_charset($connection, 'utf8');

    return $connection;
}

function addNewAuthor() {
    if ($_POST) {
        $authorName = $_POST['authorName'];
        validateAuthorName($authorName);
        $connection = connectToDatabase();
        addNewAuthorToDatabase($authorName, $connection);
    }
}

function addNewAuthorToDatabase($authorName, $connection) {
    if (authorExists($authorName, $connection)) {
        throw new Exception('The author "' . $authorName . '" already exists!');
    }
    
    $statement = mysqli_prepare($connection, 'INSERT INTO authors (author_name) Values(?)');
    mysqli_stmt_bind_param($statement, 's', $authorName);
    mysqli_stmt_execute($statement);
}

function authorExists($authorName, $connection) {
    $statement = mysqli_prepare($connection, 'SELECT author_id FROM authors WHERE author_name = ?');
    mysqli_stmt_bind_param($statement, 's', $authorName);
    mysqli_stmt_bind_result($statement, $authorId);
    mysqli_stmt_execute($statement);
    if ($authorId) {
        return true;
    }
    
    return false;
}

function validateAuthorName(&$authorName) {
    if (mb_strlen($authorName) < MIN_AUTHOR_NAME_LENGTH) {
        throw new Exception('Author name should be at least ' . MIN_AUTHOR_NAME_LENGTH . 'characters!');
    }

    if (mb_strlen($authorName) > MAX_AUTHOR_NAME_LENGTH) {
        throw new Exception('Author name should be less that ' . MAX_AUTHOR_NAME_LENGTH . 'characters!');
    }

    $authorName = trim($authorName);
    $authorName = htmlspecialchars($authorName);
}

function getAllAuthors() {
    $connection = connectToDatabase();
    $statement = mysqli_prepare($connection, 'SELECT author_id ,author_name FROM authors');
    mysqli_stmt_bind_result($statement, $authorId , $authorName);
    mysqli_stmt_execute($statement);
    $authors = NULL;

    while (mysqli_stmt_fetch($statement)) {
        $author['authorId'] = $authorId;
        $author['authorName'] = $authorName;
        $authors[] = $author;
    }

    return $authors;
}