<?php
$pageTitle = 'Нова автор';
include './includes/header.php';
$authors = getAllAuthors();
try {
    addNewAuthor();
    echo '<p>Author added successfuly.</p>';
} catch (Exception $exc) {
    echo '<p>' . $exc->getMessage() . '</p>';
}
?>
<a href="new-book.php">Книги</a>
<form method="POST">
    <label for="authorName">Автор: </label>
    <input type="text" id="authorName" name="authorName" />
    <input type="submit" value="Добави" />
</form>
<?php
if (isset($authors)) {
    ?>
    <table border="1px solid black">
        <thead>
            <tr><th>Автори</th></tr>
        </thead>
        <tbody>
            <?php
            foreach ($authors as $author) {
                echo '<tr><td><a href="#">' . $author['authorName'] . '</a></td></tr>';
            }
            ?>
        </tbody>
    </table>
    <?php
}
include './includes/footer.php';