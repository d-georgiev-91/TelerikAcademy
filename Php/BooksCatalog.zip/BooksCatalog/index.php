<?php
$pageTitle = 'Каталог с книги';
include './includes/header.php';
?>
<a href="new-book.php">Нова книга</a>
<a href="new-author.php">Нов автор</a>
<?php
include './includes/footer.php';